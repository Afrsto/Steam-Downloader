addappid(3070520)
addappid(3070521,1,"a624ab03d223bb7e405e6c834738fca46393c4cf737fb3b154202f53dbc62c18")
setManifestid(3070521,"6917235011166786810")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]