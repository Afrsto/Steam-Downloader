-- 2208570's Lua and Manifest Created by Hubcap Manifest
-- Dark Hours
-- Created: April 23, 2026 at 14:28:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2208570, 1, "316275117545cc4b53ea54b4ddae1486ebbf38d41bac8d7c78d25e4b6b5bca6f") -- Dark Hours
-- MAIN APP DEPOTS
addappid(2208571, 1, "0712fda8075e570ec33f25a8e1d2f12b0027b76e2d415ee0433e2099eafe4c03") -- Depot 2208571
setManifestid(2208571, "6982319397937482963", 2238082719)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)