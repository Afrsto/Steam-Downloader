-- Generated with Luie @ https://lua.tools/
-- 2492670 - METAL GEAR SOLID 4: Guns of the Patriots - Master Collection Version
-- Generated 2026-08-31 20:31:12 UTC
-- # Depots (Total/DLC/Shared): 7/2/3

-- Main AppID
addappid(2492670, 1, "830c133797a2197024ecf032226f8d6493f2df50affd3c8f481ff2043f9bf2f1")

-- Main Depots
addappid(2492671, 1, "a74a5c0f9354b87ee132746f97dca2e436e66f48b1e4e1bca974e23415b04471") -- (windows)
setManifestid(2492671, "1875973235293599215", 24501734674)

-- DLC's (no depot keys required)
addappid(3397310) -- METAL GEAR SOLID 4: Guns of the Patriots - Master Collection Version Pre-Order Bonus

-- DLC's (with depot keys)
-- METAL GEAR SOLID 4: Guns of the Patriots - Master Collection Version Japanese Language Pack (AppID: 2743890)
addappid(2743890)
addappid(2743890, 1, "01eed52ca6695cc38890967aa0a0030b0bec13a0d4a1e2848ebb544cb93d7618")
setManifestid(2743890, "687647022669389448", 14943786962)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 2492672, 2743880
